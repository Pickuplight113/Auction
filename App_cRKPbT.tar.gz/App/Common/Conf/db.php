<?php return array (
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'rm-uf6ra986u1u4hd42u.mysql.rds.aliyuncs.com',
  'DB_NAME' => 'sh_huaxiaepai',
  'DB_USER' => 'huaxiapt01',
  'DB_PWD' => 'HUAXIAputong087@',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'hx_',
  'DB_FIELDS_CACHE' => true,
  'DB_CHARSET' => 'utf8',
);